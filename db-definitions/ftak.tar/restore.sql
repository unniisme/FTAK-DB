--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14 (Ubuntu 12.14-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.14 (Ubuntu 12.14-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ftak;
--
-- Name: ftak; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ftak WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_IN' LC_CTYPE = 'en_IN';


ALTER DATABASE ftak OWNER TO postgres;

\connect ftak

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: approve_farmer_depot_requests(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.approve_farmer_depot_requests() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ 
BEGIN
  IF NEW.approved THEN
    INSERT INTO farmer_depot (farmer_id, depot_id)
    VALUES (NEW.farmer_id, NEW.depot_id);
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.approve_farmer_depot_requests() OWNER TO postgres;

--
-- Name: approve_farmer_plot_requests(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.approve_farmer_plot_requests() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.approved THEN
        INSERT INTO farmer_plot (farmer_id, plot_size, longitude, latitude)
        VALUES (NEW.farmer_id, NEW.plot_size, NEW.longitude, NEW.latitude);
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.approve_farmer_plot_requests() OWNER TO postgres;

--
-- Name: approve_farmer_product_requests(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.approve_farmer_product_requests() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ 
BEGIN
  IF NEW.approved THEN
    IF EXISTS (SELECT * FROM farmer_depot WHERE farmer_id = NEW.farmer_id AND depot_id = NEW.depot_id) THEN
        INSERT INTO farmer_product (farmer_id, product_id, quantity, depot_id)
        VALUES (NEW.farmer_id, NEW.product_id, NEW.quantity, NEW.depot_id);
    ELSE
        RAISE EXCEPTION 'Farmer-depot combination is not valid.';
        UPDATE farmer_product_approval SET approved = FALSE WHERE id = NEW.id;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.approve_farmer_product_requests() OWNER TO postgres;

--
-- Name: check_trade_quantity(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.check_trade_quantity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    product_quantity INT;
BEGIN
    SELECT quantity INTO product_quantity FROM farmer_product 
    WHERE farmer_product_id = NEW.farmer_product_id AND depot_id = NEW.depot_id;
    
    IF NEW.quantity > product_quantity THEN
        RAISE EXCEPTION 'Trade quantity cannot be greater than product quantity';
    ELSE
        -- Decrease the quantity in the farmer_product table
        UPDATE farmer_product 
        SET quantity = quantity - NEW.quantity 
        WHERE farmer_product_id = NEW.farmer_product_id AND depot_id = NEW.depot_id;
        RETURN NEW;
    END IF;
END;
$$;


ALTER FUNCTION public.check_trade_quantity() OWNER TO postgres;

--
-- Name: get_farmer_product_id(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_farmer_product_id(_product_id integer, _quantity integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
  suitable_farmer_product_id INT;
BEGIN
  SELECT farmer_product_id FROM farmer_product fp WHERE fp.product_id = _product_id AND fp.quantity >= _quantity ORDER BY fp.quantity DESC LIMIT 1 INTO suitable_farmer_product_id;
  RETURN suitable_farmer_product_id;
END;
$$;


ALTER FUNCTION public.get_farmer_product_id(_product_id integer, _quantity integer) OWNER TO postgres;

--
-- Name: insert_approved_products(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_approved_products()
    LANGUAGE plpgsql
    AS $$
DECLARE
  new_product_id INT;
BEGIN
  INSERT INTO product (name, description, rate, image_link)
  SELECT name, description, rate, image_link
  FROM new_product_approval
  WHERE approved = TRUE
  RETURNING product_id INTO new_product_id;
  
  INSERT INTO farmer_product_approval (farmer_id, product_id, quantity, depot_id, approved, entry_time)
  SELECT farmer_id, new_product_id, quantity, depot_id, FALSE, entry_time
  FROM new_product_approval
  WHERE approved = TRUE;

  DELETE FROM new_product_approval
  WHERE approved = TRUE;
END;
$$;


ALTER PROCEDURE public.insert_approved_products() OWNER TO postgres;

--
-- Name: insert_approved_trades(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_approved_trades()
    LANGUAGE plpgsql
    AS $$
DECLARE
    approved_rec RECORD;
    suitable_farmer_product_id INT;
    product_rate DECIMAL(10,2);
    product_depot_id INT;
BEGIN
    FOR approved_rec IN SELECT * FROM trade_request WHERE approved = TRUE LOOP
        SELECT get_farmer_product_id(approved_rec.product_id, approved_rec.quantity) INTO suitable_farmer_product_id;

        SELECT rate FROM product WHERE product.product_id = approved_rec.product_id INTO product_rate;
        SELECT depot_id FROM farmer_product WHERE farmer_product_id = suitable_farmer_product_id INTO product_depot_id;

        IF suitable_farmer_product_id IS NULL THEN
            RAISE WARNING 'No farmer has enough quantity of the product. Could not insert trade.';
            UPDATE trade_request SET approved = FALSE WHERE id = approved_rec.id;
        ELSE
          INSERT INTO trade (farmer_product_id, customer_id, quantity, depot_id, unit_rate, amount, rate) VALUES (suitable_farmer_product_id, approved_rec.customer_id, approved_rec.quantity, product_depot_id, product_rate, approved_rec.quantity * product_rate, product_rate);
        END IF;

    END LOOP;

    DELETE FROM trade_request WHERE approved = TRUE;
END;
$$;


ALTER PROCEDURE public.insert_approved_trades() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    address_id integer NOT NULL,
    city_id integer NOT NULL,
    country_id integer NOT NULL,
    street_name character varying(100) NOT NULL,
    street_number character varying(20),
    postal_code character varying(20)
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: address_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.address_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.address_address_id_seq OWNER TO postgres;

--
-- Name: address_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.address_address_id_seq OWNED BY public.address.address_id;


--
-- Name: city; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.city (
    city_id integer NOT NULL,
    country_id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.city OWNER TO postgres;

--
-- Name: city_city_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.city_city_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.city_city_id_seq OWNER TO postgres;

--
-- Name: city_city_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.city_city_id_seq OWNED BY public.city.city_id;


--
-- Name: country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.country (
    country_id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.country OWNER TO postgres;

--
-- Name: country_country_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.country_country_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.country_country_id_seq OWNER TO postgres;

--
-- Name: country_country_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.country_country_id_seq OWNED BY public.country.country_id;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customer_id integer NOT NULL,
    customer_username character varying(50) NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    phone_number character varying(20) NOT NULL
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_customer_id_seq OWNER TO postgres;

--
-- Name: customer_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_customer_id_seq OWNED BY public.customer.customer_id;


--
-- Name: depot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.depot (
    depot_id integer NOT NULL,
    name character varying(100) NOT NULL,
    address_id integer NOT NULL
);


ALTER TABLE public.depot OWNER TO postgres;

--
-- Name: depot_depot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.depot_depot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.depot_depot_id_seq OWNER TO postgres;

--
-- Name: depot_depot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.depot_depot_id_seq OWNED BY public.depot.depot_id;


--
-- Name: farmer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.farmer (
    farmer_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    dob date NOT NULL,
    doj date NOT NULL,
    phone_number character varying(20) NOT NULL,
    address_id integer NOT NULL
);


ALTER TABLE public.farmer OWNER TO postgres;

--
-- Name: farmer_depot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.farmer_depot (
    farmer_depot_id integer NOT NULL,
    farmer_id integer NOT NULL,
    depot_id integer NOT NULL
);


ALTER TABLE public.farmer_depot OWNER TO postgres;

--
-- Name: farmer_depot_approval; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.farmer_depot_approval (
    id integer NOT NULL,
    farmer_id integer NOT NULL,
    depot_id integer NOT NULL,
    approved boolean NOT NULL,
    entry_time timestamp without time zone
);


ALTER TABLE public.farmer_depot_approval OWNER TO postgres;

--
-- Name: farmer_depot_approval_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.farmer_depot_approval_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.farmer_depot_approval_id_seq OWNER TO postgres;

--
-- Name: farmer_depot_approval_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.farmer_depot_approval_id_seq OWNED BY public.farmer_depot_approval.id;


--
-- Name: farmer_depot_farmer_depot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.farmer_depot_farmer_depot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.farmer_depot_farmer_depot_id_seq OWNER TO postgres;

--
-- Name: farmer_depot_farmer_depot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.farmer_depot_farmer_depot_id_seq OWNED BY public.farmer_depot.farmer_depot_id;


--
-- Name: farmer_depot_info; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.farmer_depot_info AS
 SELECT farmer.first_name,
    farmer.last_name,
    depot.name,
    address.street_name,
    address.street_number,
    address.postal_code,
    city.name AS city_name,
    country.name AS country_name
   FROM (((((public.farmer
     JOIN public.farmer_depot ON ((farmer.farmer_id = farmer_depot.farmer_id)))
     JOIN public.depot ON ((farmer_depot.depot_id = depot.depot_id)))
     JOIN public.address ON ((depot.address_id = address.address_id)))
     JOIN public.city ON ((address.city_id = city.city_id)))
     JOIN public.country ON ((address.country_id = country.country_id)));


ALTER TABLE public.farmer_depot_info OWNER TO postgres;

--
-- Name: farmer_farmer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.farmer_farmer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.farmer_farmer_id_seq OWNER TO postgres;

--
-- Name: farmer_farmer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.farmer_farmer_id_seq OWNED BY public.farmer.farmer_id;


--
-- Name: farmer_login; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.farmer_login (
    username character varying(100) NOT NULL,
    farmer_id integer NOT NULL
);


ALTER TABLE public.farmer_login OWNER TO postgres;

--
-- Name: farmer_plot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.farmer_plot (
    plot_id integer NOT NULL,
    farmer_id integer NOT NULL,
    plot_size integer NOT NULL,
    longitude numeric NOT NULL,
    latitude numeric NOT NULL
);


ALTER TABLE public.farmer_plot OWNER TO postgres;

--
-- Name: farmer_plot_approval; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.farmer_plot_approval (
    id integer NOT NULL,
    farmer_id integer NOT NULL,
    plot_size integer NOT NULL,
    longitude numeric NOT NULL,
    latitude numeric NOT NULL,
    approved boolean NOT NULL,
    entry_time timestamp without time zone
);


ALTER TABLE public.farmer_plot_approval OWNER TO postgres;

--
-- Name: farmer_plot_approval_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.farmer_plot_approval_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.farmer_plot_approval_id_seq OWNER TO postgres;

--
-- Name: farmer_plot_approval_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.farmer_plot_approval_id_seq OWNED BY public.farmer_plot_approval.id;


--
-- Name: farmer_plot_plot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.farmer_plot_plot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.farmer_plot_plot_id_seq OWNER TO postgres;

--
-- Name: farmer_plot_plot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.farmer_plot_plot_id_seq OWNED BY public.farmer_plot.plot_id;


--
-- Name: farmer_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.farmer_product (
    farmer_product_id integer NOT NULL,
    farmer_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    depot_id integer NOT NULL
);


ALTER TABLE public.farmer_product OWNER TO postgres;

--
-- Name: farmer_product_approval; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.farmer_product_approval (
    id integer NOT NULL,
    farmer_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    depot_id integer NOT NULL,
    approved boolean NOT NULL,
    entry_time timestamp without time zone
);


ALTER TABLE public.farmer_product_approval OWNER TO postgres;

--
-- Name: farmer_product_approval_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.farmer_product_approval_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.farmer_product_approval_id_seq OWNER TO postgres;

--
-- Name: farmer_product_approval_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.farmer_product_approval_id_seq OWNED BY public.farmer_product_approval.id;


--
-- Name: farmer_product_farmer_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.farmer_product_farmer_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.farmer_product_farmer_product_id_seq OWNER TO postgres;

--
-- Name: farmer_product_farmer_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.farmer_product_farmer_product_id_seq OWNED BY public.farmer_product.farmer_product_id;


--
-- Name: hello_farmer_info; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.hello_farmer_info AS
 SELECT f.farmer_id,
    f.first_name,
    f.last_name,
    f.dob,
    f.doj,
    f.phone_number,
    f.address_id,
    fp.farmer_product_id,
    fp.product_id,
    fp.quantity,
    fd.depot_id,
    fpl.plot_id,
    fpl.plot_size,
    fpl.longitude,
    fpl.latitude
   FROM (((public.farmer f
     LEFT JOIN public.farmer_plot fpl ON ((fpl.farmer_id = f.farmer_id)))
     LEFT JOIN public.farmer_product fp ON ((fp.farmer_id = f.farmer_id)))
     LEFT JOIN public.farmer_depot fd ON ((fd.farmer_id = f.farmer_id)))
  WHERE (f.farmer_id = 3);


ALTER TABLE public.hello_farmer_info OWNER TO postgres;

--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    product_id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    rate numeric(10,2) NOT NULL,
    image_link character varying(50)
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: trade_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trade_request (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    approved boolean NOT NULL,
    entry_time timestamp without time zone
);


ALTER TABLE public.trade_request OWNER TO postgres;

--
-- Name: john_requests; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.john_requests AS
 SELECT p.name,
    p.rate,
    tr.quantity,
    tr.approved,
    tr.entry_time
   FROM ((public.trade_request tr
     JOIN public.customer c USING (customer_id))
     JOIN public.product p USING (product_id))
  WHERE ((c.customer_username)::text = 'john'::text);


ALTER TABLE public.john_requests OWNER TO postgres;

--
-- Name: jyothir_farmer_info; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.jyothir_farmer_info AS
 SELECT f.farmer_id,
    f.first_name,
    f.last_name,
    f.dob,
    f.doj,
    f.phone_number,
    f.address_id,
    fp.farmer_product_id,
    fp.product_id,
    fp.quantity,
    fd.depot_id,
    fpl.plot_id,
    fpl.plot_size,
    fpl.longitude,
    fpl.latitude
   FROM (((public.farmer f
     LEFT JOIN public.farmer_plot fpl ON ((fpl.farmer_id = f.farmer_id)))
     LEFT JOIN public.farmer_product fp ON ((fp.farmer_id = f.farmer_id)))
     LEFT JOIN public.farmer_depot fd ON ((fd.farmer_id = f.farmer_id)))
  WHERE (f.farmer_id = 1);


ALTER TABLE public.jyothir_farmer_info OWNER TO postgres;

--
-- Name: new_product_approval; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.new_product_approval (
    id integer NOT NULL,
    farmer_id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    rate numeric(10,2) NOT NULL,
    image_link character varying,
    quantity integer NOT NULL,
    depot_id integer NOT NULL,
    approved boolean NOT NULL,
    entry_time timestamp without time zone
);


ALTER TABLE public.new_product_approval OWNER TO postgres;

--
-- Name: new_product_approval_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.new_product_approval_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.new_product_approval_id_seq OWNER TO postgres;

--
-- Name: new_product_approval_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.new_product_approval_id_seq OWNED BY public.new_product_approval.id;


--
-- Name: product_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_product_id_seq OWNER TO postgres;

--
-- Name: product_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_product_id_seq OWNED BY public.product.product_id;


--
-- Name: trade; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trade (
    trade_id integer NOT NULL,
    farmer_product_id integer NOT NULL,
    customer_id integer NOT NULL,
    quantity integer NOT NULL,
    depot_id integer NOT NULL,
    unit_rate numeric(10,2) NOT NULL,
    amount numeric(10,2) NOT NULL,
    rate numeric(10,2) NOT NULL
);


ALTER TABLE public.trade OWNER TO postgres;

--
-- Name: trade_info; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.trade_info AS
 SELECT t.trade_id,
    (((f.first_name)::text || ' '::text) || (f.last_name)::text) AS farmer_name,
    t.quantity,
    p.name AS product_name,
    d.name AS depot_name,
    t.unit_rate,
    t.rate,
    (((c.first_name)::text || ' '::text) || (c.last_name)::text) AS customer_name,
    t.amount AS total_amount
   FROM (((((public.trade t
     JOIN public.farmer_product fp ON ((t.farmer_product_id = fp.farmer_product_id)))
     JOIN public.farmer f ON ((f.farmer_id = fp.farmer_id)))
     JOIN public.product p ON ((p.product_id = fp.product_id)))
     JOIN public.depot d ON ((t.depot_id = d.depot_id)))
     JOIN public.customer c ON ((c.customer_id = t.customer_id)));


ALTER TABLE public.trade_info OWNER TO postgres;

--
-- Name: trade_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trade_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trade_request_id_seq OWNER TO postgres;

--
-- Name: trade_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trade_request_id_seq OWNED BY public.trade_request.id;


--
-- Name: trade_trade_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trade_trade_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trade_trade_id_seq OWNER TO postgres;

--
-- Name: trade_trade_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trade_trade_id_seq OWNED BY public.trade.trade_id;


--
-- Name: address address_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address ALTER COLUMN address_id SET DEFAULT nextval('public.address_address_id_seq'::regclass);


--
-- Name: city city_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city ALTER COLUMN city_id SET DEFAULT nextval('public.city_city_id_seq'::regclass);


--
-- Name: country country_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country ALTER COLUMN country_id SET DEFAULT nextval('public.country_country_id_seq'::regclass);


--
-- Name: customer customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN customer_id SET DEFAULT nextval('public.customer_customer_id_seq'::regclass);


--
-- Name: depot depot_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depot ALTER COLUMN depot_id SET DEFAULT nextval('public.depot_depot_id_seq'::regclass);


--
-- Name: farmer farmer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer ALTER COLUMN farmer_id SET DEFAULT nextval('public.farmer_farmer_id_seq'::regclass);


--
-- Name: farmer_depot farmer_depot_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_depot ALTER COLUMN farmer_depot_id SET DEFAULT nextval('public.farmer_depot_farmer_depot_id_seq'::regclass);


--
-- Name: farmer_depot_approval id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_depot_approval ALTER COLUMN id SET DEFAULT nextval('public.farmer_depot_approval_id_seq'::regclass);


--
-- Name: farmer_plot plot_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_plot ALTER COLUMN plot_id SET DEFAULT nextval('public.farmer_plot_plot_id_seq'::regclass);


--
-- Name: farmer_plot_approval id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_plot_approval ALTER COLUMN id SET DEFAULT nextval('public.farmer_plot_approval_id_seq'::regclass);


--
-- Name: farmer_product farmer_product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_product ALTER COLUMN farmer_product_id SET DEFAULT nextval('public.farmer_product_farmer_product_id_seq'::regclass);


--
-- Name: farmer_product_approval id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_product_approval ALTER COLUMN id SET DEFAULT nextval('public.farmer_product_approval_id_seq'::regclass);


--
-- Name: new_product_approval id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.new_product_approval ALTER COLUMN id SET DEFAULT nextval('public.new_product_approval_id_seq'::regclass);


--
-- Name: product product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product ALTER COLUMN product_id SET DEFAULT nextval('public.product_product_id_seq'::regclass);


--
-- Name: trade trade_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade ALTER COLUMN trade_id SET DEFAULT nextval('public.trade_trade_id_seq'::regclass);


--
-- Name: trade_request id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade_request ALTER COLUMN id SET DEFAULT nextval('public.trade_request_id_seq'::regclass);


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (address_id, city_id, country_id, street_name, street_number, postal_code) FROM stdin;
\.
COPY public.address (address_id, city_id, country_id, street_name, street_number, postal_code) FROM '$$PATH$$/3189.dat';

--
-- Data for Name: city; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.city (city_id, country_id, name) FROM stdin;
\.
COPY public.city (city_id, country_id, name) FROM '$$PATH$$/3193.dat';

--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.country (country_id, name) FROM stdin;
\.
COPY public.country (country_id, name) FROM '$$PATH$$/3191.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customer_id, customer_username, first_name, last_name, email, phone_number) FROM stdin;
\.
COPY public.customer (customer_id, customer_username, first_name, last_name, email, phone_number) FROM '$$PATH$$/3195.dat';

--
-- Data for Name: depot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.depot (depot_id, name, address_id) FROM stdin;
\.
COPY public.depot (depot_id, name, address_id) FROM '$$PATH$$/3183.dat';

--
-- Data for Name: farmer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.farmer (farmer_id, first_name, last_name, dob, doj, phone_number, address_id) FROM stdin;
\.
COPY public.farmer (farmer_id, first_name, last_name, dob, doj, phone_number, address_id) FROM '$$PATH$$/3175.dat';

--
-- Data for Name: farmer_depot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.farmer_depot (farmer_depot_id, farmer_id, depot_id) FROM stdin;
\.
COPY public.farmer_depot (farmer_depot_id, farmer_id, depot_id) FROM '$$PATH$$/3185.dat';

--
-- Data for Name: farmer_depot_approval; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.farmer_depot_approval (id, farmer_id, depot_id, approved, entry_time) FROM stdin;
\.
COPY public.farmer_depot_approval (id, farmer_id, depot_id, approved, entry_time) FROM '$$PATH$$/3200.dat';

--
-- Data for Name: farmer_login; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.farmer_login (username, farmer_id) FROM stdin;
\.
COPY public.farmer_login (username, farmer_id) FROM '$$PATH$$/3196.dat';

--
-- Data for Name: farmer_plot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.farmer_plot (plot_id, farmer_id, plot_size, longitude, latitude) FROM stdin;
\.
COPY public.farmer_plot (plot_id, farmer_id, plot_size, longitude, latitude) FROM '$$PATH$$/3177.dat';

--
-- Data for Name: farmer_plot_approval; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.farmer_plot_approval (id, farmer_id, plot_size, longitude, latitude, approved, entry_time) FROM stdin;
\.
COPY public.farmer_plot_approval (id, farmer_id, plot_size, longitude, latitude, approved, entry_time) FROM '$$PATH$$/3198.dat';

--
-- Data for Name: farmer_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.farmer_product (farmer_product_id, farmer_id, product_id, quantity, depot_id) FROM stdin;
\.
COPY public.farmer_product (farmer_product_id, farmer_id, product_id, quantity, depot_id) FROM '$$PATH$$/3181.dat';

--
-- Data for Name: farmer_product_approval; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.farmer_product_approval (id, farmer_id, product_id, quantity, depot_id, approved, entry_time) FROM stdin;
\.
COPY public.farmer_product_approval (id, farmer_id, product_id, quantity, depot_id, approved, entry_time) FROM '$$PATH$$/3202.dat';

--
-- Data for Name: new_product_approval; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.new_product_approval (id, farmer_id, name, description, rate, image_link, quantity, depot_id, approved, entry_time) FROM stdin;
\.
COPY public.new_product_approval (id, farmer_id, name, description, rate, image_link, quantity, depot_id, approved, entry_time) FROM '$$PATH$$/3204.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (product_id, name, description, rate, image_link) FROM stdin;
\.
COPY public.product (product_id, name, description, rate, image_link) FROM '$$PATH$$/3179.dat';

--
-- Data for Name: trade; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trade (trade_id, farmer_product_id, customer_id, quantity, depot_id, unit_rate, amount, rate) FROM stdin;
\.
COPY public.trade (trade_id, farmer_product_id, customer_id, quantity, depot_id, unit_rate, amount, rate) FROM '$$PATH$$/3187.dat';

--
-- Data for Name: trade_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trade_request (id, customer_id, product_id, quantity, approved, entry_time) FROM stdin;
\.
COPY public.trade_request (id, customer_id, product_id, quantity, approved, entry_time) FROM '$$PATH$$/3206.dat';

--
-- Name: address_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.address_address_id_seq', 10, true);


--
-- Name: city_city_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.city_city_id_seq', 14, true);


--
-- Name: country_country_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.country_country_id_seq', 6, true);


--
-- Name: customer_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_customer_id_seq', 9, true);


--
-- Name: depot_depot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.depot_depot_id_seq', 5, true);


--
-- Name: farmer_depot_approval_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.farmer_depot_approval_id_seq', 6, true);


--
-- Name: farmer_depot_farmer_depot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.farmer_depot_farmer_depot_id_seq', 6, true);


--
-- Name: farmer_farmer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.farmer_farmer_id_seq', 4, true);


--
-- Name: farmer_plot_approval_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.farmer_plot_approval_id_seq', 4, true);


--
-- Name: farmer_plot_plot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.farmer_plot_plot_id_seq', 4, true);


--
-- Name: farmer_product_approval_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.farmer_product_approval_id_seq', 5, true);


--
-- Name: farmer_product_farmer_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.farmer_product_farmer_product_id_seq', 4, true);


--
-- Name: new_product_approval_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.new_product_approval_id_seq', 6, true);


--
-- Name: product_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_product_id_seq', 6, true);


--
-- Name: trade_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trade_request_id_seq', 17, true);


--
-- Name: trade_trade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trade_trade_id_seq', 9, true);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (address_id);


--
-- Name: city city_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city
    ADD CONSTRAINT city_pkey PRIMARY KEY (city_id);


--
-- Name: country country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT country_pkey PRIMARY KEY (country_id);


--
-- Name: customer customer_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_customer_id_key UNIQUE (customer_id);


--
-- Name: customer customer_customer_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_customer_username_key UNIQUE (customer_username);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id, customer_username);


--
-- Name: depot depot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depot
    ADD CONSTRAINT depot_pkey PRIMARY KEY (depot_id);


--
-- Name: farmer_depot_approval farmer_depot_approval_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_depot_approval
    ADD CONSTRAINT farmer_depot_approval_pkey PRIMARY KEY (id);


--
-- Name: farmer_depot farmer_depot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_depot
    ADD CONSTRAINT farmer_depot_pkey PRIMARY KEY (farmer_depot_id);


--
-- Name: farmer_login farmer_login_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_login
    ADD CONSTRAINT farmer_login_pkey PRIMARY KEY (username);


--
-- Name: farmer farmer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer
    ADD CONSTRAINT farmer_pkey PRIMARY KEY (farmer_id);


--
-- Name: farmer_plot_approval farmer_plot_approval_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_plot_approval
    ADD CONSTRAINT farmer_plot_approval_pkey PRIMARY KEY (id);


--
-- Name: farmer_plot farmer_plot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_plot
    ADD CONSTRAINT farmer_plot_pkey PRIMARY KEY (plot_id);


--
-- Name: farmer_product_approval farmer_product_approval_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_product_approval
    ADD CONSTRAINT farmer_product_approval_pkey PRIMARY KEY (id);


--
-- Name: farmer_product farmer_product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_product
    ADD CONSTRAINT farmer_product_pkey PRIMARY KEY (farmer_product_id);


--
-- Name: new_product_approval new_product_approval_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.new_product_approval
    ADD CONSTRAINT new_product_approval_pkey PRIMARY KEY (id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (product_id);


--
-- Name: trade trade_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade
    ADD CONSTRAINT trade_pkey PRIMARY KEY (trade_id);


--
-- Name: trade_request trade_request_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade_request
    ADD CONSTRAINT trade_request_pkey PRIMARY KEY (id);


--
-- Name: farmer_product_quantity_gt_zero_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX farmer_product_quantity_gt_zero_idx ON public.farmer_product USING btree (farmer_id, product_id) WHERE (quantity > 0);


--
-- Name: farmer_username_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX farmer_username_idx ON public.farmer_login USING btree (username);


--
-- Name: farmer_depot_approval approve_farmer_depot_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER approve_farmer_depot_trigger AFTER UPDATE OF approved ON public.farmer_depot_approval FOR EACH ROW EXECUTE FUNCTION public.approve_farmer_depot_requests();


--
-- Name: farmer_plot_approval approve_farmer_plot_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER approve_farmer_plot_trigger AFTER UPDATE OF approved ON public.farmer_plot_approval FOR EACH ROW EXECUTE FUNCTION public.approve_farmer_plot_requests();


--
-- Name: farmer_product_approval approve_farmer_product_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER approve_farmer_product_trigger AFTER UPDATE OF approved ON public.farmer_product_approval FOR EACH ROW EXECUTE FUNCTION public.approve_farmer_product_requests();


--
-- Name: trade check_trade_quantity_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER check_trade_quantity_trigger BEFORE INSERT ON public.trade FOR EACH ROW EXECUTE FUNCTION public.check_trade_quantity();


--
-- Name: farmer address_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer
    ADD CONSTRAINT address_fk FOREIGN KEY (address_id) REFERENCES public.address(address_id);


--
-- Name: depot address_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depot
    ADD CONSTRAINT address_fk FOREIGN KEY (address_id) REFERENCES public.address(address_id);


--
-- Name: address city_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT city_fk FOREIGN KEY (city_id) REFERENCES public.city(city_id);


--
-- Name: address country_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT country_fk FOREIGN KEY (country_id) REFERENCES public.country(country_id);


--
-- Name: city country_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city
    ADD CONSTRAINT country_fk FOREIGN KEY (country_id) REFERENCES public.country(country_id);


--
-- Name: trade customer_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade
    ADD CONSTRAINT customer_fk FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: farmer_depot depot_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_depot
    ADD CONSTRAINT depot_fk FOREIGN KEY (depot_id) REFERENCES public.depot(depot_id);


--
-- Name: trade depot_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade
    ADD CONSTRAINT depot_fk FOREIGN KEY (depot_id) REFERENCES public.depot(depot_id);


--
-- Name: farmer_depot_approval farmer_depot_approval_depot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_depot_approval
    ADD CONSTRAINT farmer_depot_approval_depot_id_fkey FOREIGN KEY (depot_id) REFERENCES public.depot(depot_id);


--
-- Name: farmer_depot_approval farmer_depot_approval_farmer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_depot_approval
    ADD CONSTRAINT farmer_depot_approval_farmer_id_fkey FOREIGN KEY (farmer_id) REFERENCES public.farmer(farmer_id);


--
-- Name: farmer_depot farmer_depot_depot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_depot
    ADD CONSTRAINT farmer_depot_depot_id_fkey FOREIGN KEY (depot_id) REFERENCES public.depot(depot_id);


--
-- Name: farmer_depot farmer_depot_farmer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_depot
    ADD CONSTRAINT farmer_depot_farmer_id_fkey FOREIGN KEY (farmer_id) REFERENCES public.farmer(farmer_id);


--
-- Name: farmer_product farmer_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_product
    ADD CONSTRAINT farmer_fk FOREIGN KEY (farmer_id) REFERENCES public.farmer(farmer_id);


--
-- Name: farmer_depot farmer_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_depot
    ADD CONSTRAINT farmer_fk FOREIGN KEY (farmer_id) REFERENCES public.farmer(farmer_id);


--
-- Name: farmer_login farmer_login_farmer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_login
    ADD CONSTRAINT farmer_login_farmer_id_fkey FOREIGN KEY (farmer_id) REFERENCES public.farmer(farmer_id);


--
-- Name: farmer_plot_approval farmer_plot_approval_farmer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_plot_approval
    ADD CONSTRAINT farmer_plot_approval_farmer_id_fkey FOREIGN KEY (farmer_id) REFERENCES public.farmer(farmer_id);


--
-- Name: farmer_plot farmer_plot_farmer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_plot
    ADD CONSTRAINT farmer_plot_farmer_id_fkey FOREIGN KEY (farmer_id) REFERENCES public.farmer(farmer_id);


--
-- Name: farmer_product_approval farmer_product_approval_depot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_product_approval
    ADD CONSTRAINT farmer_product_approval_depot_id_fkey FOREIGN KEY (depot_id) REFERENCES public.depot(depot_id);


--
-- Name: farmer_product_approval farmer_product_approval_farmer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_product_approval
    ADD CONSTRAINT farmer_product_approval_farmer_id_fkey FOREIGN KEY (farmer_id) REFERENCES public.farmer(farmer_id);


--
-- Name: farmer_product_approval farmer_product_approval_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_product_approval
    ADD CONSTRAINT farmer_product_approval_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id);


--
-- Name: farmer_product farmer_product_farmer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_product
    ADD CONSTRAINT farmer_product_farmer_id_fkey FOREIGN KEY (farmer_id) REFERENCES public.farmer(farmer_id);


--
-- Name: farmer_product farmer_product_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_product
    ADD CONSTRAINT farmer_product_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id);


--
-- Name: trade fp_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade
    ADD CONSTRAINT fp_fk FOREIGN KEY (farmer_product_id) REFERENCES public.farmer_product(farmer_product_id);


--
-- Name: new_product_approval new_product_approval_depot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.new_product_approval
    ADD CONSTRAINT new_product_approval_depot_id_fkey FOREIGN KEY (depot_id) REFERENCES public.depot(depot_id);


--
-- Name: new_product_approval new_product_approval_farmer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.new_product_approval
    ADD CONSTRAINT new_product_approval_farmer_id_fkey FOREIGN KEY (farmer_id) REFERENCES public.farmer(farmer_id);


--
-- Name: farmer_product product_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farmer_product
    ADD CONSTRAINT product_fk FOREIGN KEY (product_id) REFERENCES public.product(product_id);


--
-- Name: trade_request trade_request_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade_request
    ADD CONSTRAINT trade_request_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: trade_request trade_request_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trade_request
    ADD CONSTRAINT trade_request_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(product_id);


--
-- Name: TABLE address; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.address TO farmer;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.address TO supervisor;
GRANT SELECT ON TABLE public.address TO customer;


--
-- Name: SEQUENCE address_address_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.address_address_id_seq TO farmer;


--
-- Name: TABLE city; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.city TO farmer;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.city TO supervisor;


--
-- Name: SEQUENCE city_city_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.city_city_id_seq TO farmer;


--
-- Name: TABLE country; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.country TO farmer;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.country TO supervisor;


--
-- Name: SEQUENCE country_country_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.country_country_id_seq TO farmer;


--
-- Name: TABLE customer; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.customer TO supervisor;


--
-- Name: SEQUENCE customer_customer_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.customer_customer_id_seq TO farmer;


--
-- Name: TABLE depot; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.depot TO farmer;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.depot TO supervisor;
GRANT SELECT ON TABLE public.depot TO customer;


--
-- Name: SEQUENCE depot_depot_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.depot_depot_id_seq TO farmer;


--
-- Name: TABLE farmer; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.farmer TO supervisor;


--
-- Name: TABLE farmer_depot; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.farmer_depot TO supervisor;


--
-- Name: TABLE farmer_depot_approval; Type: ACL; Schema: public; Owner: postgres
--

GRANT INSERT ON TABLE public.farmer_depot_approval TO farmer;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.farmer_depot_approval TO supervisor;


--
-- Name: SEQUENCE farmer_depot_approval_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.farmer_depot_approval_id_seq TO farmer;


--
-- Name: SEQUENCE farmer_depot_farmer_depot_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.farmer_depot_farmer_depot_id_seq TO farmer;


--
-- Name: TABLE farmer_depot_info; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.farmer_depot_info TO supervisor;


--
-- Name: SEQUENCE farmer_farmer_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.farmer_farmer_id_seq TO farmer;


--
-- Name: TABLE farmer_login; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.farmer_login TO supervisor;


--
-- Name: TABLE farmer_plot; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.farmer_plot TO supervisor;


--
-- Name: TABLE farmer_plot_approval; Type: ACL; Schema: public; Owner: postgres
--

GRANT INSERT ON TABLE public.farmer_plot_approval TO farmer;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.farmer_plot_approval TO supervisor;


--
-- Name: SEQUENCE farmer_plot_approval_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.farmer_plot_approval_id_seq TO farmer;


--
-- Name: SEQUENCE farmer_plot_plot_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.farmer_plot_plot_id_seq TO farmer;


--
-- Name: TABLE farmer_product; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.farmer_product TO supervisor;


--
-- Name: TABLE farmer_product_approval; Type: ACL; Schema: public; Owner: postgres
--

GRANT INSERT ON TABLE public.farmer_product_approval TO farmer;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.farmer_product_approval TO supervisor;


--
-- Name: SEQUENCE farmer_product_approval_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.farmer_product_approval_id_seq TO farmer;


--
-- Name: SEQUENCE farmer_product_farmer_product_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.farmer_product_farmer_product_id_seq TO farmer;


--
-- Name: TABLE hello_farmer_info; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.hello_farmer_info TO hello;


--
-- Name: TABLE product; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.product TO farmer;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.product TO supervisor;
GRANT SELECT ON TABLE public.product TO customer;


--
-- Name: TABLE trade_request; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.trade_request TO supervisor;
GRANT INSERT ON TABLE public.trade_request TO customer;


--
-- Name: TABLE john_requests; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.john_requests TO john;


--
-- Name: TABLE jyothir_farmer_info; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.jyothir_farmer_info TO jyothir;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.jyothir_farmer_info TO supervisor;


--
-- Name: TABLE new_product_approval; Type: ACL; Schema: public; Owner: postgres
--

GRANT INSERT ON TABLE public.new_product_approval TO farmer;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.new_product_approval TO supervisor;


--
-- Name: SEQUENCE new_product_approval_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.new_product_approval_id_seq TO farmer;


--
-- Name: SEQUENCE product_product_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.product_product_id_seq TO farmer;


--
-- Name: TABLE trade; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.trade TO supervisor;


--
-- Name: TABLE trade_info; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.trade_info TO supervisor;


--
-- Name: SEQUENCE trade_request_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.trade_request_id_seq TO farmer;
GRANT SELECT,USAGE ON SEQUENCE public.trade_request_id_seq TO customer;


--
-- Name: SEQUENCE trade_trade_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.trade_trade_id_seq TO farmer;


--
-- PostgreSQL database dump complete
--

